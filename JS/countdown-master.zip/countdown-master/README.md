# Cuenta regresiva para Navidad | HTML-CSS-JS
### Video del tutorial: [https://youtu.be/K5_0o-zkLzA](https://youtu.be/K5_0o-zkLzA)
![COUNTDOWN](https://user-images.githubusercontent.com/85034795/129838464-05b695f7-9120-4bf2-955b-66b982ed6bf3.png)
